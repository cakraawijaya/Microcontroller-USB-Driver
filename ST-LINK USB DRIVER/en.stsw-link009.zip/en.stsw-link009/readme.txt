Digitally signed USB driver for ST-Link/V2 on Windows7, Windows8 and Windows10,
32 and 64 bits.

To install the driver, run stlink_winusb_install.bat in administrator mode, before
connecting any ST-Link to the PC.

In case of issue, it's also possible to run (as administrator):
 - dpinst_x86.exe on 32 bits machines
 - dpinst_amd64.exe on 64 bits machines